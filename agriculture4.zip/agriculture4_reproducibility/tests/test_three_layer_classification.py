"""Smoke tests for the rule-based Agriculture 4.0 classifier."""
import importlib.util
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "src" / "three_layer_classification.py"
SPEC = importlib.util.spec_from_file_location("three_layer_classification", MODULE_PATH)
classifier = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(classifier)


def test_classifier_dictionary_self_tests():
    """Run the positive, negative, punctuation, and field-logic checks."""
    classifier.self_test()
